/**
 * Class: CMSC203 
 *  Program: Assignment 3
 *  Instructor: Dagmawi Delelegne
 * Description: This program encrypts the text provided with two different methods.
   A program that requires you to use functions to calculate the volume of a box and the    volume of a Sphere.
 * Due: 3/07/2023 (<03/26/2020>)
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: Dagmawi Delelegne
*/

public class CryptoManager {
	
	private static final char LOWER_BOUND = ' ';
	private static final char UPPER_BOUND = '_';
	private static final int RANGE = UPPER_BOUND - LOWER_BOUND + 1;

	/**
	 * This method determines if a string is within the allowable bounds of ASCII codes 
	 * according to the LOWER_BOUND and UPPER_BOUND characters
	 * @param plainText a string to be encrypted, if it is within the allowable bounds
	 * @return true if all characters are within the allowable bounds, false if any character is outside
	 */
	public static boolean stringInBounds (String plainText) {
		//throw new RuntimeException("method not implemented");
		boolean inRange = true;
		    for ( int i = 0; i < plainText.length(); i++) {
		        int asciiCode = (int) plainText.charAt(i);
		        if (asciiCode < (int)LOWER_BOUND || asciiCode > (int)UPPER_BOUND) {
		        	inRange = false;
		            return inRange;
		        }
		    } 
		    return inRange;
		
	}

	/**
	 * Encrypts a string according to the Caesar Cipher.  The integer key specifies an offset
	 * and each character in plainText is replaced by the character \"offset\" away from it 
	 * @param plainText an uppercase string to be encrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the encrypted string
	 */
	public static String encryptCaesar(String plainText, int key) {
		
		char [] plain = plainText.toCharArray();
		for(int i = 0 ; i < plain.length; i++) 	{	
			plain[i] += key;
			while(plain[i] > 95) {
				plain[i] = (char)(plain[i] - 64);
			}
		}
		
		plainText = String.valueOf(plain);
		return plainText;
		
		//throw new RuntimeException("method not implemented");
	}
	
	/**
	 * Decrypts a string according to the Caesar Cipher.  The integer key specifies an offset
	 * and each character in encryptedText is replaced by the character \"offset\" characters before it.
	 * This is the inverse of the encryptCaesar method.
	 * @param encryptedText an encrypted string to be decrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the plain text string
	 */
	public static String decryptCaesar(String encryptedText, int key) {
		
		return encryptCaesar(encryptedText,key*-1);
	}
	
	/**
	 * Encrypts a string according the Bellaso Cipher.  Each character in plainText is offset 
	 * according to the ASCII value of the corresponding character in bellasoStr, which is repeated
	 * to correspond to the length of plainText
	 * @param plainText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the encrypted string
	 */
	public static String encryptBellaso(String plainText, String bellasoStr) {
		
		    StringBuilder sb = new StringBuilder();
		    int bellasoIndex = 0;
		    for (int i = 0; i < plainText.length(); i++) {
		        int plainCode = (int) plainText.charAt(i);
		        int bellasoCode = (int) bellasoStr.charAt(bellasoIndex);
		        int offset = plainCode + bellasoCode;
		        while (offset > UPPER_BOUND) {
		        	offset -= 64;
		        }
		        while (offset < LOWER_BOUND) {
		        	offset += 64;
		        }
		        
		        sb.append((char) offset);
		        bellasoIndex = (bellasoIndex + 1) % bellasoStr.length();
		    }
		    return sb.toString();
		
		
			
	}
	
	
	/**
	 * Decrypts a string according the Bellaso Cipher.  Each character in encryptedText is replaced by
	 * the character corresponding to the character in bellasoStr, which is repeated
	 * to correspond to the length of plainText.  This is the inverse of the encryptBellaso method.
	 * @param encryptedText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the decrypted string
	 */
	public static String decryptBellaso(String encryptedText, String bellasoStr) {
		
		StringBuilder sb = new StringBuilder();
	    int bellasoIndex = 0;
	    for (int i = 0; i < encryptedText.length(); i++) {
	        int encryptedCode = (int) encryptedText.charAt(i);
	        int bellasoCode = (int) bellasoStr.charAt(bellasoIndex);
	        int offset = encryptedCode - bellasoCode;
	        while (offset > UPPER_BOUND) {
	            offset -= RANGE;
	        }
	        while (offset < LOWER_BOUND) {
	            offset += RANGE;
	        }
	        sb.append((char) offset);
	        bellasoIndex = (bellasoIndex + 1) % bellasoStr.length();
	    }
	    return sb.toString();
	
		
	}
}
